

class PSGGripper():
    def __init__(self):
        pass

    def get_position(self):
        return 0

    def get_force(self):
        return 0

    def set_dead_zone(self, v):
        return 0

    def get_dead_zone(self):
        return 0

    def is_moving(self):
        return 0

    def has_error(self):
        return False

    def stop(self):
        pass

    def close(self):
        pass

    def open(self):
        pass